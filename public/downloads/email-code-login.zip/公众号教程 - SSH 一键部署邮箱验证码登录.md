# 用 SSH 一键部署邮箱验证码登录

> **微信公众号：小产品实验室**  
> 微信搜索「小产品实验室」并关注，获取更多云主机实操教程、实用工具和更新。  
> **主页** [tinylabpro.com](https://tinylabpro.com/) · **好物分享** [教程与下载](https://tinylabpro.com/share)

部署完成后，访客访问你的站点 `/account/`，输入邮箱，再填写收到的六位验证码。首次验证成功会创建账号，以后用同一个邮箱即可登录。应用使用 PHP 和 SQLite，从一台已经开好、可以 SSH 登录的云主机开始。示例用 Ubuntu，也说明了已有 PHP 托管空间时可以跳过哪些步骤。

## 开始前先分清三个地方

- **你自己的电脑**用来打开终端、登录 SSH 和下载安装包。
- **SSH 登录后的服务器终端**用来执行安装命令。登录成功后，提示符通常会变成类似 `demo@server:~$`。输入 `exit` 可以回到自己的电脑。
- **浏览器**用来管理域名、查看邮件，以及测试最终的登录页面。

代码框里的命令可以复制。遇到 `example.com`、`YOUR_...` 或明确标注为示例的用户名、端口、路径，先换成自己的值。命令执行完、终端重新出现提示符后，再做下一步。

## 1. 准备你自己的信息

在托管服务商的控制面板或开通邮件里找到 SSH 主机、端口和用户名。另准备你的网站域名，以及一个获准通过邮件服务发送验证码的发件邮箱。

| 你要替换的值 | 示例 | 从哪里找 |
| --- | --- | --- |
| SSH 主机 | `ssh.example.com` | 服务商控制台或开通邮件 |
| SSH 端口 | `2222` | 服务商控制台或开通邮件，常规 SSH 也可能用 22 |
| SSH 用户名 | `demo` | 服务商控制台或开通邮件 |
| 网站域名 | `www.example.com` | 你能管理 DNS 的域名 |
| 发件邮箱 | `verify@example.com` | 你开通并获准发信的地址 |

SSH 主机、网站域名和发件邮箱可以各用不同域名。把实际值填到对应的位置即可。代码会把你传入的邮箱用作发件人。

## 2. 登录 SSH

### Windows 10 / 11

打开「开始」菜单，搜索并打开 **PowerShell**。也可以打开「Windows 终端」后选择 PowerShell。先运行 `ssh -V`。如果看到 OpenSSH 版本号，就可以直接连接。

如果提示找不到 `ssh`，右键 PowerShell，选择「以管理员身份运行」，安装 Windows 的 **OpenSSH 客户端**：

```powershell
Add-WindowsCapability -Online -Name OpenSSH.Client~~~~0.0.1.0
```

安装后重新打开普通 PowerShell，再运行一次 `ssh -V`。 [微软 OpenSSH 安装说明](https://learn.microsoft.com/en-us/windows-server/administration/openssh/openssh_install_firstuse)

### Mac

按 `Command + 空格`，搜索并打开「终端」。

### 输入登录命令

在 PowerShell 或 Mac 终端运行下面这条命令。实际登录信息可在开通邮件或服务商控制台找到。

```sh
ssh -p 2222 demo@ssh.example.com
```

**命令里的示例值**：`2222` 换成 SSH 端口，`demo` 换成 SSH 用户名，`ssh.example.com` 换成 SSH 主机名或公网 IP。

首次连接时，核对托管商提供的 SSH 主机指纹再接受。如果你的套餐使用密码登录，请先打开托管商发来的**开通邮件**，找到初始 SSH 登录密码。看到终端的密码提示后，输入该密码并回车。终端输入密码时不会显示字符。使用密钥的读者按托管商给出的登录方式连接即可。

看到远程提示符后，运行 `whoami`，应该显示开通邮件里的 SSH 用户名。若登录失败，先看终端最后一行提示：

| 提示 | 怎么处理 |
| --- | --- |
| `Could not resolve hostname` | 检查主机名是否拼错。命令中只填主机名或公网 IP，省去 `https://` 和末尾的斜杠。 |
| `Connection timed out` | 确认云主机正在运行，公网地址正确，云防火墙允许你的电脑访问实际 SSH 端口。 |
| `Connection refused` | 核对端口，并从服务商的网页控制台检查 SSH 服务是否正在监听。 |
| `Permission denied` | 核对用户名和开通邮件中的密码。若提示 `publickey` 且没有密码提示，按服务商的密钥登录说明操作。 |
| `REMOTE HOST IDENTIFICATION HAS CHANGED` | 暂停登录，通过服务商控制台核对新的主机指纹。确认确实更换过主机或重装后，再按服务商说明更新本机记录。 |

登录后可以运行以下命令确认当前目录和已有环境。如果这是空白云主机，找不到 PHP 或 `public_html` 就按下一节准备：

```sh
pwd
ls -ld public_html
php -v
```

如果使用已有托管空间，请切换到包含 `public_html` 的目录，例如 `/workspace`。安装脚本会检查 PHP 语法及 `pdo_sqlite`。

## 3. 在空白 Ubuntu 上准备网站

这一节面向已经开好、可以用 `sudo` 的 Ubuntu 云主机。如果主机已提供 `public_html`、HTTPS 和 PHP 发信功能，直接跳到「安装」。以下命令在 **SSH 登录后的服务器终端**执行。

先在云主机的网络规则里允许公网访问 TCP 80 和 443。如果系统防火墙已启用，也允许这两个端口。把你的域名 A 记录指向云主机公网 IPv4。如果域名有 AAAA 记录，确保它也指向这台机器并能访问，否则先移除不正确的 AAAA 记录。后续命令里的域名统一填你自己的。

Apache 负责让浏览器打开你的网站，PHP 负责处理验证码登录，SQLite 负责存账号。Certbot 负责为你的域名申请 HTTPS 证书。下面这一条安装命令会把它们装齐。

```sh
sudo apt update
sudo apt install apache2 php-cli libapache2-mod-php php-sqlite3 sqlite3 certbot python3-certbot-apache msmtp ca-certificates
```

安装过程中如果提示 `Do you want to continue? [Y/n]`，输入 `y` 并回车。若系统问是否启用 msmtp 的 AppArmor，保留默认选项。安装完成后可以运行 `php -v`，应看到 PHP 版本号。

在同一个 SSH 窗口，把下面第一行换成你已经解析到主机的域名，然后执行整段。示例使用独立目录 `/var/www/my-account-site`。

```sh
SITE_DOMAIN='login.example.com'
# 上一行换成已解析到云主机的实际域名。
SITE_ROOT='/var/www/my-account-site'
# 上一行是教程使用的站点目录，可以照用。若改路径，后续安装和权限命令也要一起改。
sudo install -d -m 755 -o "$USER" -g "$(id -gn)" "$SITE_ROOT" "$SITE_ROOT/public_html"

sudo tee /etc/apache2/sites-available/my-account-site.conf >/dev/null <<EOF_APACHE
<VirtualHost *:80>
    ServerName $SITE_DOMAIN
    DocumentRoot $SITE_ROOT/public_html
    <Directory $SITE_ROOT/public_html>
        Require all granted
        Options -Indexes
        AllowOverride None
    </Directory>
</VirtualHost>
EOF_APACHE

sudo a2ensite my-account-site
sudo apache2ctl configtest && sudo systemctl reload apache2
sudo certbot --apache --redirect -d "$SITE_DOMAIN"
```

Certbot 提示时按说明完成证书申请。若失败，先确认域名已经解析到这台机器、云防火墙允许 TCP 80，且 Apache 正在运行。应用的会话 Cookie 要求 HTTPS，签发成功再做登录测试。

上面先让 Apache 用你的域名提供网站，再用 Certbot 申请证书并把 HTTP 自动跳转到 HTTPS。成功后，浏览器就可以用 `https://你的域名` 加密访问这台服务器。接下来配置验证码发信。

打开浏览器访问 `https://你的域名`。能打开页面或看到 Apache 返回的默认响应，且浏览器没有证书错误，说明 HTTPS 已经接通。网站根路径此时可能还没有首页，安装后用 `/account/` 验收。如果连不上，可以按顺序检查：

1. 在本机用 `nslookup 你的域名` 查看解析结果，IPv4 应该是云主机的公网地址。刚改 DNS 时，等解析生效后再试。
2. 在服务器上运行 `sudo systemctl status apache2 --no-pager`。看到 `active (running)` 表示 Apache 正在运行。
3. 如果 Apache 正常但浏览器访问超时，检查云防火墙和系统防火墙是否都允许 TCP 80、443。如果证书申请失败，也先检查这两处。
4. 如果提示 Apache 配置错误，运行 `sudo apache2ctl configtest`，按报错里的文件和行号改正，看到 `Syntax OK` 再重新加载。

### 让 PHP 能发送验证码

准备一个允许通过 SMTP 发信的邮箱或邮件服务。从服务商取到 **SMTP 主机、端口、登录名、密码或应用专用密码、获准使用的发件地址**。以下示例使用 **587 + STARTTLS**。服务商若给的是其他端口或加密方式，请按它的说明修改。云主机还需要能出站连接服务商的 SMTP 端口。

用管理员权限创建仅 root 和 Apache 用户组能读的配置文件：

```sh
sudo touch /etc/msmtprc
sudo chown root:www-data /etc/msmtprc
sudo chmod 640 /etc/msmtprc
SUDO_EDITOR=nano sudoedit /etc/msmtprc
```

编辑器打开后粘贴下面的内容。完成后按 `Ctrl+O`、回车保存，再按 `Ctrl+X` 退出。如果系统提示找不到 nano，先运行 `sudo apt install nano`。

填入以下内容，替换示例值。SMTP 密码只填在这个配置文件里。发件地址要和下一节脚本使用的地址一致。邮件服务商要求域名验证时，按它给出的 DNS 记录完成验证。

```text
defaults
auth on
tls on
tls_starttls on
tls_trust_file /etc/ssl/certs/ca-certificates.crt

account default
host smtp.example.com
# 上一行换成邮件服务商提供的 SMTP 主机。
port 587
# 587 对应本例的 STARTTLS。若服务商给了其他端口或加密方式，请一起调整端口和 tls_starttls。
from verify@example.com
# 上一行是示例，请换成你的 SMTP 服务商允许使用的发件邮箱，并与安装脚本填写的地址一致。
user YOUR_SMTP_USERNAME
# 上一行换成 SMTP 登录名，按服务商给出的值填写。
password YOUR_SMTP_APP_PASSWORD
# 上一行换成 SMTP 密码或应用专用密码，只填在这个私有配置文件中。
```

让 Apache 里的 PHP 调用 msmtp：

```sh
PHP_VERSION_DIR=$(php -r 'echo PHP_MAJOR_VERSION, ".", PHP_MINOR_VERSION;')
printf '%s\n' 'sendmail_path = "/usr/bin/msmtp -t"' |
  sudo tee "/etc/php/$PHP_VERSION_DIR/apache2/conf.d/99-account-mail.ini" >/dev/null
sudo systemctl restart apache2
```

[msmtp 官方手册](https://marlam.de/msmtp/msmtp.html)

## 4. 安装，任选一种方式

空白 Ubuntu 按上面的命令配置后，先执行 `cd /var/www/my-account-site`。已有托管空间请进入包含 `public_html` 的目录。

### 方式 A：直接粘贴到 SSH 终端

打开随附的 `SSH 终端粘贴版.sh`，用文本编辑器把第一行的 `verify@YOUR-DOMAIN.example` 改成你自己的发件邮箱。先在 SSH 终端进入包含 `public_html` 的目录，再把文件的**全部纯文本**从第一行复制到最后一行，粘贴进终端，必要时按回车。看到「安装完成」即可进入下一步。若一直显示 `>`，通常是脚本没粘贴完整。按 `Ctrl+C` 取消，再从第一行到最后一行完整粘贴。

这份文件已经包含安装逻辑和 PHP 页面。粘贴前可以先阅读代码。粘贴时保留末尾的 `LXI_INSTALL_BLOCK`，不要复制 Markdown 的代码围栏。

### 方式 B：用 SFTP 上传后运行安装脚本

从安装包里解压 `install.sh` 和 `index.php`。在**本机**终端切换到解压目录，执行：

```sh
sftp -P 2222 demo@ssh.example.com
```

这里的端口、用户名和主机地址换成 SSH 登录时使用的值。SFTP 的端口参数是大写 `-P`。

登录成功后，在 `sftp>` 提示符下逐行输入：

```text
mkdir account-setup
cd account-setup
put install.sh
put index.php
pwd
bye
```

记下 `pwd` 显示的远端上传目录。回到 SSH 终端运行：

```sh
sh "$HOME/account-setup/install.sh" /var/www/my-account-site verify@example.com
```

如果 SFTP 上传目录和 SSH 的 `$HOME/account-setup` 不同，第一个路径用刚才 `pwd` 的结果拼上 `/install.sh`。第二个路径换成包含 `public_html` 的目录，最后换成你的发件邮箱。两个文件要在同一目录，只运行 `install.sh`。如果目标 `public_html/account` 已存在，脚本会停止，保护已有应用和数据。

### Ubuntu 部署后的目录权限

如果你按本教程用 Ubuntu 的 Apache 部署，安装后让 Apache 用户 `www-data` 管理 SQLite 私有目录。已有托管空间通常由托管商处理 PHP 进程的身份，可跳过这两条命令。

```sh
sudo chown -R www-data:www-data /var/www/my-account-site/.website-accounts
sudo chmod 700 /var/www/my-account-site/.website-accounts
```

安装后在 SSH 里运行 `ls -l public_html/account/index.php`。能看到文件就可以继续。如果安装没成功：

| 提示 | 怎么处理 |
| --- | --- |
| 找不到 `public_html` | 先用 `pwd` 看当前目录。按 Ubuntu 示例部署的读者运行 `cd /var/www/my-account-site`，再执行安装。 |
| PHP 缺少 `pdo_sqlite` | Ubuntu 上运行 `sudo apt install php-sqlite3`，重启 Apache 后重试。托管空间请在面板启用该扩展或联系服务商。 |
| `Permission denied` | 检查是否进入了你有写权限的网站目录。按上文 Ubuntu 示例建站时，确认站点目录的拥有者是你当前的 SSH 用户。 |
| `account` 目录已存在 | 先访问现有的 `/account/`。确认是已有安装就按升级步骤处理。若是其他应用占用了路径，保留原目录，换一个独立站点目录安装。 |
| 找不到 `index.php` | SFTP 方式需要把 `index.php` 和 `install.sh` 上传到同一个远端目录。粘贴方式则需要复制脚本的全部内容。 |

## 5. 在自己的域名验收

浏览器打开 `https://www.example.com/account/`，把示例域名换成自己的。输入一个你能收信的邮箱，点击「发送验证码」。回到同一浏览器填写六位码，确认进入个人页面。再退出并重新登录一次。

- 如果网页显示 404，核对域名对应的网页根目录和是否存在 `public_html/account/index.php`。
- 如果页面报发信失败，查托管面板的 PHP 或网站错误日志。确认发件地址已获准，并询问托管商网页 PHP 是否允许用 `mail()` 发信。只有 SMTP 账号的主机可能需要另接带认证的 SMTP，这个安装包使用的是 PHP `mail()`。
- 如果页面显示发送成功但收不到，先看垃圾邮件和邮件服务商的发送记录。PHP 接受邮件只代表交给了发信程序。以收件箱实际收到为准。
- 如果 SMTP 报认证失败，检查 SMTP 用户名和应用专用密码。报发件人不允许时，核对安装时填的发件邮箱与 `/etc/msmtprc` 里的 `from` 是否一致，以及该地址是否已经在邮件服务商处获准发信。
- 如果 SMTP 连接超时，核对 SMTP 主机、端口和加密方式，确认云主机允许出站连接该端口。若是 Ubuntu，可在服务器查看 `sudo tail -n 50 /var/log/apache2/error.log`，重点找 `msmtp`、`PDO` 或 `Permission denied` 的报错。
- 如果页面报账号服务不可用，Ubuntu 部署先检查上一节的目录权限命令是否执行，再看 Apache 错误日志。若看到 SQLite 无法打开数据库，确认 `www-data` 对 `.website-accounts` 有读写权限。
- 如果验证码过期或提示错误，在原浏览器页面重新申请。优先使用最新邮件里的六位码。验证码有效期为 10 分钟，试错 5 次后要重新申请。发送过于频繁时等一分钟再试。
- 如果能收信但验证后总回登录页，确认始终用同一个浏览器和 HTTPS 域名完成两步，并允许该站点保存 Cookie。

## 6. 部署后怎么管理

数据库会在首次提交有效邮箱时建立在网页根目录外的 `.website-accounts/accounts.sqlite`。发件地址保存在同目录的 `sender` 文件。备份时保留私有目录和应用代码，升级前备份数据库与旧代码。安装脚本适用于首次部署，已有站点升级时先在测试目录验证新版本再替换线上文件。

- **备份账号**：在 Ubuntu 服务器运行以下命令，用 SQLite 导出 SQL 备份。把备份下载到另一处。首次提交有效邮箱后才会有数据库文件。

  ```sh
  umask 077
  BACKUP="$HOME/accounts-$(date +%Y%m%d-%H%M%S).sql"
  sudo -u www-data sqlite3 /var/www/my-account-site/.website-accounts/accounts.sqlite .dump > "$BACKUP"
  ```

- **换发件邮箱**：更新私有目录里的 `sender`。如果更换邮件服务商，也更新 `/etc/msmtprc`，再完成一次真实收信测试。
- **升级页面**：备份 SQLite 和旧页面，上传新 `index.php`，运行 `php -l` 检查后再替换 `public_html/account/index.php`，然后验证登录和退出。
- **接入自己的功能**：当前安装包提供登录和一个个人页面。要加入会员内容或个人资料，可以先把需要登录的 PHP 页面放在 `/account/` 下，统一使用同一套会话配置，并在服务器端逐页检查登录状态和数据归属。当前会话 Cookie 的路径是 `/account/`。如果要让站点其他路径共用登录，需要专门调整会话和权限检查。
- **正式开放前**：安装后任何能验证邮箱的访客都可以注册，常见一次性邮箱域名会被拒绝。当前按来源 IP 和邮箱限制发码频率。上线前根据邮件配额补充全站发信上限，并验证备份能恢复。
