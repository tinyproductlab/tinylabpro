# 用 SSH 一键部署邮箱验证码登录

部署完成后，访客访问你的站点 `/account/`，输入邮箱，再填写收到的六位验证码。首次验证成功会创建账号，以后用同一个邮箱即可登录。应用使用 PHP 和 SQLite，从一台已经开好、可以 SSH 登录的云主机开始。示例用 Ubuntu，也说明了已有 PHP 托管空间时可以跳过哪些步骤。

## 1. 准备你自己的信息

在托管服务商的控制面板或开通邮件里找到 SSH 主机、端口和用户名。另准备你的网站域名，以及一个获准通过邮件服务发送验证码的发件邮箱。

| 你要替换的值 | 示例 | 从哪里找 |
| --- | --- | --- |
| SSH 主机 | `ssh.example.com` | 服务商控制台或开通邮件 |
| SSH 端口 | `2222` | 服务商控制台或开通邮件，常规 SSH 也可能用 22 |
| SSH 用户名 | `demo` | 服务商控制台或开通邮件 |
| 网站域名 | `www.example.com` | 你能管理 DNS 的域名 |
| 发件邮箱 | `verify@example.com` | 你开通并获准发信的地址 |

SSH 主机、网站域名和发件邮箱可以各用不同域名。把实际值填到对应的位置即可。代码会把你传入的邮箱用作发件人。

## 2. 登录 SSH

在 Mac 打开「终端」，Windows 打开 PowerShell，替换示例里的三项信息后执行：

```sh
ssh -p 2222 demo@ssh.example.com
```

首次连接时，核对托管商提供的 SSH 主机指纹再接受。看到密码提示后，输入托管账户的 SSH 密码并回车。终端输入密码时不会显示字符。使用密钥的读者按托管商给出的登录方式连接即可。

登录后可以运行以下命令确认当前目录和已有环境。如果这是空白云主机，找不到 PHP 或 `public_html` 就按下一节准备：

```sh
pwd
ls -ld public_html
php -v
```

如果使用已有托管空间，请切换到包含 `public_html` 的目录，例如 `/workspace`。安装脚本会检查 PHP 语法及 `pdo_sqlite`。

## 3. 在空白 Ubuntu 上准备网站

这一节面向已经开好、可以用 `sudo` 的 Ubuntu 云主机。如果主机已提供 `public_html`、HTTPS 和 PHP 发信功能，直接跳到「安装」。以下命令在 **SSH 登录后的服务器终端**执行。

先在云主机的网络规则里允许公网访问 TCP 80 和 443。如果系统防火墙已启用，也允许这两个端口。把你的域名 A 记录指向云主机公网 IPv4。如果域名有 AAAA 记录，确保它也指向这台机器并能访问，否则先移除不正确的 AAAA 记录。后续命令里的域名统一填你自己的。

安装网站组件：

```sh
sudo apt update
sudo apt install apache2 php-cli libapache2-mod-php php-sqlite3 sqlite3 certbot python3-certbot-apache msmtp ca-certificates
```

在同一个 SSH 窗口，把下面第一行换成你已经解析到主机的域名，然后执行整段。示例使用独立目录 `/var/www/my-account-site`。

```sh
SITE_DOMAIN='login.example.com'
SITE_ROOT='/var/www/my-account-site'
sudo install -d -m 755 -o "$USER" -g "$(id -gn)" "$SITE_ROOT" "$SITE_ROOT/public_html"

sudo tee /etc/apache2/sites-available/my-account-site.conf >/dev/null <<EOF_APACHE
<VirtualHost *:80>
    ServerName $SITE_DOMAIN
    DocumentRoot $SITE_ROOT/public_html
    <Directory $SITE_ROOT/public_html>
        Require all granted
        Options -Indexes
        AllowOverride None
    </Directory>
</VirtualHost>
EOF_APACHE

sudo a2ensite my-account-site
sudo apache2ctl configtest && sudo systemctl reload apache2
sudo certbot --apache --redirect -d "$SITE_DOMAIN"
```

Certbot 提示时按说明完成证书申请。若失败，先确认域名已经解析到这台机器、云防火墙允许 TCP 80，且 Apache 正在运行。应用的会话 Cookie 要求 HTTPS，签发成功再做登录测试。

- [Ubuntu Apache 文档](https://ubuntu.com/server/docs/how-to/web-services/install-apache2/)
- [Certbot 官方安装与使用说明](https://certbot.eff.org/instructions?ws=apache&os=pip)

### 让 PHP 能发送验证码

准备一个允许通过 SMTP 发信的邮箱或邮件服务。从服务商取到 **SMTP 主机、端口、登录名、密码或应用专用密码、获准使用的发件地址**。以下示例使用 **587 + STARTTLS**。服务商若给的是其他端口或加密方式，请按它的说明修改。云主机还需要能出站连接服务商的 SMTP 端口。

用管理员权限创建仅 root 和 Apache 用户组能读的配置文件：

```sh
sudo touch /etc/msmtprc
sudo chown root:www-data /etc/msmtprc
sudo chmod 640 /etc/msmtprc
sudoedit /etc/msmtprc
```

填入以下内容，替换示例值。SMTP 密码只填在这个配置文件里。发件地址要和下一节脚本使用的地址一致。邮件服务商要求域名验证时，按它给出的 DNS 记录完成验证。

```text
defaults
auth on
tls on
tls_starttls on
tls_trust_file /etc/ssl/certs/ca-certificates.crt

account default
host smtp.example.com
port 587
from verify@example.com
user YOUR_SMTP_USERNAME
password YOUR_SMTP_APP_PASSWORD
```

让 Apache 里的 PHP 调用 msmtp：

```sh
PHP_VERSION_DIR=$(php -r 'echo PHP_MAJOR_VERSION, ".", PHP_MINOR_VERSION;')
printf '%s\n' 'sendmail_path = "/usr/bin/msmtp -t"' |
  sudo tee "/etc/php/$PHP_VERSION_DIR/apache2/conf.d/99-account-mail.ini" >/dev/null
sudo systemctl restart apache2
```

[msmtp 官方手册](https://marlam.de/msmtp/msmtp.html)

## 4. 安装，任选一种方式

空白 Ubuntu 按上面的命令配置后，先执行 `cd /var/www/my-account-site`。已有托管空间请进入包含 `public_html` 的目录。

### 方式 A：直接粘贴到 SSH 终端

打开随附的 `SSH 终端粘贴版.sh`，用文本编辑器把第一行的 `verify@YOUR-DOMAIN.example` 改成你自己的发件邮箱。先在 SSH 终端进入包含 `public_html` 的目录，再把文件的**全部纯文本**从第一行复制到最后一行，粘贴进终端，必要时按回车。看到「安装完成」即可进入下一步。

这份文件已经包含安装逻辑和 PHP 页面。粘贴前可以先阅读代码。粘贴时保留末尾的 `LXI_INSTALL_BLOCK`，不要复制 Markdown 的代码围栏。

### 方式 B：用 SFTP 上传后运行安装脚本

从安装包里解压 `install.sh` 和 `index.php`。在**本机**终端切换到解压目录，执行：

```sh
sftp -P 2222 demo@ssh.example.com
```

登录成功后，在 `sftp>` 提示符下逐行输入：

```text
mkdir account-setup
cd account-setup
put install.sh
put index.php
pwd
bye
```

记下 `pwd` 显示的远端上传目录。回到 SSH 终端运行：

```sh
sh "$HOME/account-setup/install.sh" /var/www/my-account-site verify@example.com
```

如果 SFTP 上传目录和 SSH 的 `$HOME/account-setup` 不同，第一个路径用刚才 `pwd` 的结果拼上 `/install.sh`。第二个路径换成包含 `public_html` 的目录，最后换成你的发件邮箱。两个文件要在同一目录，只运行 `install.sh`。如果目标 `public_html/account` 已存在，脚本会停止，保护已有应用和数据。

### Ubuntu 部署后的目录权限

如果你按本教程用 Ubuntu 的 Apache 部署，安装后让 Apache 用户 `www-data` 管理 SQLite 私有目录。已有托管空间通常由托管商处理 PHP 进程的身份，可跳过这两条命令。

```sh
sudo chown -R www-data:www-data /var/www/my-account-site/.website-accounts
sudo chmod 700 /var/www/my-account-site/.website-accounts
```

## 5. 在自己的域名验收

浏览器打开 `https://www.example.com/account/`，把示例域名换成自己的。输入一个你能收信的邮箱，点击「发送验证码」。回到同一浏览器填写六位码，确认进入个人页面。再退出并重新登录一次。

- 如果网页显示 404，核对域名对应的网页根目录和是否存在 `public_html/account/index.php`。
- 如果页面报发信失败，查托管面板的 PHP 或网站错误日志。确认发件地址已获准，并询问托管商网页 PHP 是否允许用 `mail()` 发信。只有 SMTP 账号的主机可能需要另接带认证的 SMTP，这个安装包使用的是 PHP `mail()`。
- 如果页面显示发送成功但收不到，先看垃圾邮件和托管商的发信记录。PHP 接受邮件只代表交给了发信程序。以收件箱实际收到为准。

## 6. 部署后怎么管理

数据库会在首次提交有效邮箱时建立在网页根目录外的 `.website-accounts/accounts.sqlite`。发件地址保存在同目录的 `sender` 文件。备份时保留私有目录和应用代码，升级前备份数据库与旧代码。安装脚本适用于首次部署，已有站点升级时先在测试目录验证新版本再替换线上文件。

- **备份账号**：在 Ubuntu 服务器运行以下命令，用 SQLite 导出 SQL 备份。把备份下载到另一处。首次提交有效邮箱后才会有数据库文件。

  ```sh
  umask 077
  BACKUP="$HOME/accounts-$(date +%Y%m%d-%H%M%S).sql"
  sudo -u www-data sqlite3 /var/www/my-account-site/.website-accounts/accounts.sqlite .dump > "$BACKUP"
  ```

- **换发件邮箱**：更新私有目录里的 `sender`。如果更换邮件服务商，也更新 `/etc/msmtprc`，再完成一次真实收信测试。
- **升级页面**：备份 SQLite 和旧页面，上传新 `index.php`，运行 `php -l` 检查后再替换 `public_html/account/index.php`，然后验证登录和退出。
- **接入自己的功能**：当前安装包提供登录和一个个人页面。要加入会员内容或个人资料，可以先把需要登录的 PHP 页面放在 `/account/` 下，统一使用同一套会话配置，并在服务器端逐页检查登录状态和数据归属。当前会话 Cookie 的路径是 `/account/`。如果要让站点其他路径共用登录，需要专门调整会话和权限检查。
- **正式开放前**：安装后任何能验证邮箱的访客都可以注册，常见一次性邮箱域名会被拒绝。当前按来源 IP 和邮箱限制发码频率。上线前根据邮件配额补充全站发信上限，并验证备份能恢复。
