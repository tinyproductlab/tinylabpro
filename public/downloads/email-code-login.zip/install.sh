#!/bin/sh
set -eu

source_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ "$#" -ne 2 ]; then
    echo '用法：sh install.sh 托管目录 发件邮箱' >&2
    exit 1
fi
cd "$1"
test -d public_html || { echo '请在包含 public_html 的托管目录运行脚本。' >&2; exit 1; }
php -l "$source_dir/index.php"
php -r 'exit(extension_loaded("pdo_sqlite") ? 0 : 1);' || { echo 'PHP 缺少 pdo_sqlite。' >&2; exit 1; }

php -r 'exit(filter_var($argv[1], FILTER_VALIDATE_EMAIL) ? 0 : 1);' -- "$2" ||
    { echo '发件邮箱地址格式不正确。' >&2; exit 1; }

umask 077
target=public_html/account
mkdir "$target" || { echo '无法创建 account 目录。如果已经安装，请保留现有目录。' >&2; exit 1; }
trap 'rm -f "$target/.index.tmp"; rmdir "$target" 2>/dev/null || true' EXIT
trap 'exit 1' HUP INT TERM

mkdir -p .website-accounts
printf '%s\n' "$2" > .website-accounts/sender
cp "$source_dir/index.php" "$target/.index.tmp"
chmod 644 "$target/.index.tmp"
chmod 755 "$target"
mv "$target/.index.tmp" "$target/index.php"
trap - EXIT HUP INT TERM
echo '安装完成。用浏览器访问站点的 /account/ 路径。'
