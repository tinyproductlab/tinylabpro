#!/usr/bin/env python3
"""Patch localized UI objects in compiled NIBs; preserve references and types.
Format reference: https://github.com/matsmattsson/nibsqueeze/blob/master/NibArchive.md
No third-party Python modules. Does not execute the application.
"""
import json, struct, subprocess, sys
from pathlib import Path

def table(path):
    return json.loads(subprocess.check_output(['/usr/bin/plutil','-convert','json','-o','-',str(path)]))

def varint(n):
    out=bytearray()
    while n>=128: out.append(n&127); n>>=7
    out.append(n|128)
    return bytes(out)

class Archive:
    def __init__(self,data):
        self.data=data
        if data[:10]!=b'NIBArchive' or len(data)<50: raise ValueError('Unsupported NIB archive')
        self.h=list(struct.unpack_from('<10I',data,10))
        h=self.h
        if h[0]!=1 or not (50<=h[3]<=h[5]<=h[7]<=h[9]<=len(data)): raise ValueError('Invalid NIB layout')
        def vi(p):
            n=shift=0
            while shift<=63:
                x=data[p];p+=1;n|=(x&127)<<shift
                if x&128:return n,p
                shift+=7
            raise ValueError('Invalid varint')
        self.keys=[];p=h[5]
        for _ in range(h[4]):
            n,p=vi(p);self.keys.append(data[p:p+n].decode());p+=n
        if p!=h[7]:raise ValueError('Unexpected keys layout')
        self.classes=[];p=h[9]
        for _ in range(h[8]):
            n,p=vi(p);extra,p=vi(p);p+=extra*4
            self.classes.append(data[p:p+n].rstrip(b'\0').decode());p+=n
        if p!=len(data):raise ValueError('Unexpected class trailer')
        self.objects=[];p=h[3]
        for _ in range(h[2]):
            c,p=vi(p);v,p=vi(p);n,p=vi(p)
            if c>=len(self.classes) or v+n>h[6]:raise ValueError('Invalid object')
            self.objects.append((c,v,n))
        if p!=h[5]:raise ValueError('Unexpected object layout')
        self.values=[];p=h[7]
        for _ in range(h[6]):
            k,p=vi(p);t=data[p];p+=1
            if k>=len(self.keys):raise ValueError('Invalid key')
            if t==8:n,p=vi(p)
            else:
                sizes={0:1,1:2,2:4,3:8,4:0,5:0,6:4,7:8,9:0,10:4}
                if t not in sizes:raise ValueError('Unknown value type')
                n=sizes[t]
            v=data[p:p+n];p+=n
            if len(v)!=n:raise ValueError('Truncated NIB')
            self.values.append([k,t,v])
        if p!=h[9]:raise ValueError('Unexpected values layout')
    def indexes(self,obj):
        _,start,count=self.objects[obj]
        return range(start,start+count)
    def text_index(self,obj):
        for i in self.indexes(obj):
            k,t,v=self.values[i]
            if self.keys[k]=='NS.bytes' and t==8:return i
    def text(self,obj):
        i=self.text_index(obj)
        if i is None:return None
        try:return self.values[i][2].decode('utf-8')
        except UnicodeDecodeError:return None
    def serialize(self):
        values=bytearray()
        for k,t,v in self.values:
            values+=varint(k)+bytes([t])
            if t==8:values+=varint(len(v))
            values+=v
        h=self.h.copy();h[9]=h[7]+len(values)
        result=b'NIBArchive'+struct.pack('<10I',*h)+self.data[50:self.h[7]]+values+self.data[self.h[9]:]
        parsed=Archive(result)
        if parsed.objects!=self.objects or parsed.keys!=self.keys or parsed.classes!=self.classes or parsed.values!=self.values:raise ValueError('Round trip failed')
        return result
    def translate(self,translated,fallback):
        changed=0;missing=set()
        def settext(obj,text):
            nonlocal changed
            i=self.text_index(obj)
            if i is not None and self.values[i][2]!=text.encode():
                self.values[i][2]=text.encode();changed+=1
        for obj,(c,v,n) in enumerate(self.objects):
            if self.classes[c]!='NSLocalizableString':continue
            refs={self.keys[self.values[i][0]]:struct.unpack('<I',self.values[i][2])[0] for i in self.indexes(obj) if self.values[i][1]==10}
            key=self.text(refs['NSKey']) if 'NSKey' in refs else None
            original=self.text(obj)
            chinese=translated.get(key) or fallback.get(original)
            if chinese:
                settext(obj,chinese)
                if 'NSDev' in refs:settext(refs['NSDev'],chinese)
            elif original and any(x.isalpha() for x in original):missing.add(original)
        # Some labels use plain NSString instead of NSLocalizableString.
        for obj,(c,_,_) in enumerate(self.objects):
            if self.classes[c] not in ('NSString','NSMutableString'):continue
            old=self.text(obj)
            if old in fallback:settext(obj,fallback[old])
        return changed,sorted(missing)

def patch(app,lang):
    res=app/'Contents/Resources'
    zh={};fallback={};ambiguous=set()
    def clean(v):return v[2:] if v.startswith('xx') else v
    for name in ('Main.strings','Localize.strings'):
        original=table(res/'en.lproj'/name);translated=table(lang/name)
        if original.keys()!=translated.keys():raise ValueError('Language keys do not match this MacUtil version: '+name)
        translated={k:clean(v) for k,v in translated.items()}
        if name=='Main.strings':zh=translated
        for k,v in original.items():
            target=translated[k]
            if v==target:continue
            if v in fallback and fallback[v]!=target:ambiguous.add(v)
            fallback[v]=target
    for k in ambiguous:fallback.pop(k,None)
    fallback.update({'Quick Cleanup':'快速清理','Cleaning':'清理','Performance':'性能','Security':'安全','Safe Cleaning':'安全清理','Junk Cleaner':'垃圾清理','Logs Cleaner':'日志清理','Trash Cleaner':'废纸篓清理','Partial Downloads':'未完成下载','Memory Optimizer':'内存优化','Duplicates Finder':'重复文件查找','Smart Uninstaller':'智能卸载','Startup Items':'启动项','Clipboard':'剪贴板','Shredder':'文件粉碎','Privacy Protection':'隐私保护','Large Files':'大文件','General':'通用','MacUtil Preferences':'MacUtil 偏好设置','Application Settings':'应用设置','Application Update':'应用更新','Check for Updates now':'立即检查更新','Launch Automatically at System Startup':'开机自动启动','Install updates Automatically':'自动安装更新','Show App In Status bar':'在菜单栏显示应用','Auto Scan for Quick Cleanup on System Startup':'开机自动扫描快速清理','Continue':'继续','Lock Any App':'锁定应用','Hide Files & Folders':'隐藏文件和文件夹'})
    extra=lang.parent/'additional.json'
    if extra.exists():fallback.update(json.loads(extra.read_text()))
    runtime={}
    for k,v in fallback.items():
        runtime[k]=v
        if k.startswith('xx'):runtime[k[2:]]=v
    (res/'MacUtilRuntimeChinese.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
    report={'version':7,'files':[],'changed_values':0,'untranslated':[]}
    missing=set()
    for path in sorted(res.rglob('*.nib')):
        if path.is_symlink():raise ValueError('Symlink NIB is unsupported')
        raw=path.read_bytes()
        if not raw.startswith(b'NIBArchive'):raise ValueError('Unsupported NIB: '+str(path))
        archive=Archive(raw)
        if archive.serialize()!=raw:raise ValueError('No-op round trip differs: '+str(path))
        count,remaining=archive.translate(zh,fallback)
        if count:
            path.write_bytes(archive.serialize())
            report['files'].append({'path':str(path.relative_to(res)),'changed':count})
            report['changed_values']+=count
        missing.update(remaining)
    # Keep both normal localization and explicit English-table lookups translated.
    for folder in ['zh-Hans.lproj','en.lproj']:
        (res/folder).mkdir(exist_ok=True)
        for name in ['Main.strings','Localize.strings']:
            values={k:clean(v) for k,v in table(lang/name).items()}
            (res/folder/name).write_text('\n'.join(json.dumps(k,ensure_ascii=False)+' = '+json.dumps(v,ensure_ascii=False)+';' for k,v in values.items())+'\n')
            subprocess.run(['/usr/bin/plutil','-lint',str(res/folder/name)],check=True,stdout=subprocess.DEVNULL)
    report['untranslated']=sorted(missing)
    if report['changed_values']==0:raise ValueError('No interface text changed; refusing false success')
    (res/'MacUtilChinesePatch.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps({'changed_values':report['changed_values'],'changed_nibs':len(report['files']),'untranslated_unique':len(missing)},ensure_ascii=False))

if __name__=='__main__':
    try:
        app=Path(sys.argv[1]);lang=Path(sys.argv[2])
        patch(app,lang)
        import shutil
        from inject_library import inject
        frameworks=app/'Contents/Frameworks';frameworks.mkdir(exist_ok=True)
        shutil.copy2(lang.parent/'MacUtilChinese.dylib',frameworks/'MacUtilChinese.dylib')
        inject(app/'Contents/MacOS/MacUtil')
    except Exception as e:print('汉化失败：'+str(e),file=sys.stderr);sys.exit(1)
