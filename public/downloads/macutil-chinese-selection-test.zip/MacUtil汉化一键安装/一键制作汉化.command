#!/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
fail() { printf '\n制作失败：%s\n原软件未被覆盖。\n' "$1" >&2; exit 1; }
trap 'printf "\n如有错误，请保留本窗口的完整输出。\n"; if [ -t 0 ]; then read -r -p "按回车关闭…" _ || true; fi' EXIT
printf 'MacUtil 汉化版 · 只制作独立测试副本\n'
APP_PATH="${1:-/Applications/MacUtil.app}"
[ -d "$APP_PATH" ] || fail "未找到 $APP_PATH。可以把 MacUtil.app 拖到此脚本后作为参数运行。"
[ ! -L "$APP_PATH" ] || fail '不处理符号链接。请选择真实应用。'
INFO="$APP_PATH/Contents/Info.plist"
VERSION="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$INFO")"
BID="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$INFO")"
[ "$BID" = com.isolve.macutil-product ] || fail '这不是预期的 MacUtil 应用。'
[ "$VERSION" = 2.0.9 ] || fail "本包仅验证了 MacUtil 2.0.9；当前版本为 $VERSION，停止处理。"
PYTHON="$(command -v python3 || true)"
[ -n "$PYTHON" ] || fail '需要已安装的 Python 3，本脚本不会自动下载安装工具。'
"$PYTHON" -c 'import sys; assert sys.version_info >= (3,8)' || fail '需要 Python 3.8 或更高版本。'
[ -f "$SCRIPT_DIR/patch_resources.py" ] || fail '缺少配套处理程序，请完整解压。'
for name in Main Localize; do
  /usr/bin/plutil -lint "$SCRIPT_DIR/zh-Hans.lproj/$name.strings" || fail '翻译表格式错误。'
done
OUTPUT_PARENT="${2:-$HOME/Desktop}"
[ -d "$OUTPUT_PARENT" ] || fail "输出文件夹不存在：$OUTPUT_PARENT"
OUTPUT_DIR="$(mktemp -d "$OUTPUT_PARENT/MacUtil-汉化版-XXXXXX")"
WORK_APP="$OUTPUT_DIR/MacUtil-汉化版.app"
printf '来源：%s\n输出：%s\n正在复制…\n' "$APP_PATH" "$WORK_APP"
/usr/bin/ditto "$APP_PATH" "$WORK_APP"
# The original installation is never modified, deleted or terminated.
"$PYTHON" "$SCRIPT_DIR/patch_resources.py" "$WORK_APP" "$SCRIPT_DIR/zh-Hans.lproj"
/usr/libexec/PlistBuddy -c 'Set :SUEnableAutomaticChecks false' "$WORK_APP/Contents/Info.plist" 2>/dev/null || true
/usr/libexec/PlistBuddy -c 'Set :CFBundleDisplayName MacUtil-汉化版' "$WORK_APP/Contents/Info.plist"
# Keep original entitlements when re-signing this modified test copy.
/usr/bin/codesign --force --deep --sign - --preserve-metadata=entitlements --timestamp=none "$WORK_APP"
/usr/bin/codesign --verify --deep --strict "$WORK_APP"
printf '\n制作与结构校验完成。尚未启动应用，不能仅凭此输出认定所有界面已经汉化。\n'
printf '请先从 MacUtil 菜单正常退出旧版，再打开：\n%s\n' "$WORK_APP"
printf '两份应用使用相同标识，可能共用原来的设置及授权；请勿同时打开。\n'
printf '这是修改后本地签名的测试副本；系统可能要求重新确认原有权限。脚本不移除安全隔离属性，也不代你授权。\n'
printf '原应用仍在：%s\n恢复时退出测试副本，再直接打开原应用即可。\n' "$APP_PATH"
