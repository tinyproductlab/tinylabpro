import struct
from pathlib import Path

def inject(path):
    data=bytearray(path.read_bytes())
    name=b'@executable_path/../Frameworks/MacUtilChinese.dylib\0'
    cmdsize=(24+len(name)+7)//8*8
    magic=struct.unpack_from('>I',data)[0]
    if magic==0xcafebabe:
        n=struct.unpack_from('>I',data,4)[0]
        if not 1<=n<=16:raise ValueError('Invalid architecture count')
        slices=[struct.unpack_from('>II',data,8+i*20+8) for i in range(n)]
    else:slices=[(0,len(data))]
    for base,size in slices:
        if base+size>len(data) or size<32 or struct.unpack_from('<I',data,base)[0]!=0xfeedfacf:raise ValueError('Unsupported executable')
        n,sz=struct.unpack_from('<II',data,base+16);end=base+32+sz
        if n>1024 or end>base+size:raise ValueError('Invalid header')
        pos=base+32;first=base+size;present=False
        for _ in range(n):
            kind,length=struct.unpack_from('<II',data,pos)
            if length<8 or pos+length>end:raise ValueError('Invalid load command')
            if kind==0xc and length>=24:
                off=struct.unpack_from('<I',data,pos+8)[0]
                if off>=24 and off<length and bytes(data[pos+off:pos+length]).split(b'\0')[0]==name[:-1]:present=True
            if kind==0x19:
                if length<72:raise ValueError('Invalid segment')
                ns=struct.unpack_from('<I',data,pos+64)[0]
                if 72+ns*80>length:raise ValueError('Invalid sections')
                for j in range(ns):
                    off=struct.unpack_from('<I',data,pos+72+j*80+48)[0]
                    if off:first=min(first,base+off)
            pos+=length
        if pos!=end:raise ValueError('Header length mismatch')
        if present:continue
        if end+cmdsize>first or any(data[end:end+cmdsize]):raise ValueError('No safe header padding; original retained')
        struct.pack_into('<6I',data,end,0xc,cmdsize,24,0,0,0)
        data[end+24:end+24+len(name)]=name
        struct.pack_into('<II',data,base+16,n+1,sz+cmdsize)
    path.write_bytes(data)
