#import <AppKit/AppKit.h>
#import <objc/runtime.h>
static NSDictionary *translations;
static NSString *translated(NSString *text) {
    if (![text isKindOfClass:NSString.class]) return text;
    // These labels may be read back by MacUtil's selection state logic.
    NSString *check = [text hasPrefix:@"xx"] ? [text substringFromIndex:2] : text;
    if ([@[@"Select All",@"Deselect All",@"Unselect All",@"Select None",@"Check All",@"Uncheck All"] containsObject:[check stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet]]) return text;
    NSString *value = translations[text];
    if ([value isKindOfClass:NSString.class]) return value;
    static NSArray *rules;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        rules = @[
            @[@"^([0-9][0-9,]*) issues$", @"$1 项"],
            @[@"^([0-9][0-9,]*) total Duplicate items found$", @"共找到 $1 个重复项目"],
            @[@"^([0-9]+(?:\\.[0-9]+)? [KMGT]?B) can be recovered\\.$", @"可释放 $1 空间"],
            @[@"^([◀◄←]\\s*)Start Over$", @"$1重新开始"]
        ];
    });
    for (NSArray *rule in rules) {
        NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:rule[0] options:0 error:nil];
        if ([regex firstMatchInString:text options:0 range:NSMakeRange(0,text.length)])
            return [regex stringByReplacingMatchesInString:text options:0 range:NSMakeRange(0,text.length) withTemplate:rule[1]];
    }
    NSRegularExpression *category = [NSRegularExpression regularExpressionWithPattern:@"^([0-9][0-9,]*) Duplicate (Others|Documents|Images|Archives|Applications|Music|Videos) found$" options:0 error:nil];
    NSTextCheckingResult *match = [category firstMatchInString:text options:0 range:NSMakeRange(0,text.length)];
    if (match) {
        NSString *number = [text substringWithRange:[match rangeAtIndex:1]];
        NSString *kind = [text substringWithRange:[match rangeAtIndex:2]];
        return [NSString stringWithFormat:@"找到 %@ 个%@类重复项目",number,translations[kind] ?: kind];
    }
    return text;
}
static void (*fieldString)(id,SEL,NSString *);
static void fieldSet(id self,SEL cmd,NSString *value) { fieldString(self,cmd,[(NSTextField *)self isEditable] ? value : translated(value)); }
static void (*cellString)(id,SEL,NSString *);
static void cellSet(id self,SEL cmd,NSString *value) { cellString(self,cmd,[(NSTextFieldCell *)self isEditable] ? value : translated(value)); }
static void (*buttonTitle)(id,SEL,NSString *);
static void buttonSet(id self,SEL cmd,NSString *value) { buttonTitle(self,cmd,translated(value)); }
static void (*menuTitle)(id,SEL,NSString *);
static void menuSet(id self,SEL cmd,NSString *value) { menuTitle(self,cmd,translated(value)); }
static void (*windowTitle)(id,SEL,NSString *);
static void windowSet(id self,SEL cmd,NSString *value) { windowTitle(self,cmd,translated(value)); }
static void (*fieldAttributed)(id,SEL,NSAttributedString *);
static void attrSet(id self,SEL cmd,NSAttributedString *value) {
    NSString *newValue = translated(value.string);
    if (![(NSTextField *)self isEditable] && value.length && ![newValue isEqual:value.string]) {
        NSMutableAttributedString *copy = [value mutableCopy];
        [copy replaceCharactersInRange:NSMakeRange(0,copy.length) withString:newValue];
        fieldAttributed(self,cmd,copy);
    } else fieldAttributed(self,cmd,value);
}
static IMP replace(Class cls, SEL selector, IMP replacement) {
    Method method = class_getInstanceMethod(cls,selector);
    if (!method) return NULL;
    IMP previous = method_getImplementation(method);
    if (!class_addMethod(cls,selector,replacement,method_getTypeEncoding(method))) method_setImplementation(method,replacement);
    return previous;
}
__attribute__((constructor)) static void installTranslation(void) {
    @autoreleasepool {
        if (![NSBundle.mainBundle.bundleIdentifier isEqual:@"com.isolve.macutil-product"]) return;
        NSURL *url = [NSBundle.mainBundle URLForResource:@"MacUtilRuntimeChinese" withExtension:@"json"];
        NSData *data = url ? [NSData dataWithContentsOfURL:url] : nil;
        id map = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
        if (![map isKindOfClass:NSDictionary.class]) return;
        translations = map;
        fieldString = (void *)replace(NSTextField.class,@selector(setStringValue:),(IMP)fieldSet);
        cellString = (void *)replace(NSTextFieldCell.class,@selector(setStringValue:),(IMP)cellSet);
        fieldAttributed = (void *)replace(NSTextField.class,@selector(setAttributedStringValue:),(IMP)attrSet);
        buttonTitle = (void *)replace(NSButton.class,@selector(setTitle:),(IMP)buttonSet);
        menuTitle = (void *)replace(NSMenuItem.class,@selector(setTitle:),(IMP)menuSet);
        windowTitle = (void *)replace(NSWindow.class,@selector(setTitle:),(IMP)windowSet);
    }
}
